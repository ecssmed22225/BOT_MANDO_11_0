import fetch from 'node-fetch'
let handler = async (m, { conn, command }) => {
/*if (!db.data.chats[m.chat].modohorny && m.isGroup) throw `${lenguajeGB['smsContAdult']()}`*/
let url = pies[Math.floor(Math.random() * pies.length)]
//conn.sendFile(m.chat, url, 'error.jpg', ` ♥ *استمع للراحه النفسيه* ♥                                                                                                     MANDO𝘽𝙤𝙩-𝙈𝘿`, m)
conn.sendButton(m.chat, `♥ استمع للراحه النفسيه ♥ `, author, url, [['واحد تاني🥺🤍', `/${command}`]], m)
}
handler.help = ['قران']
handler.tags = ['internet']
handler.command = /^(قران)$/
handler.exp = 50
handler.level = 0
export default handler


global.pies = [
"https://telegra.ph/file/be83a6ff3449292717d10.mp4",
"https://telegra.ph/file/9e899e4adafa72c4abd7f.mp4",
"https://telegra.ph/file/c5877d11222f59b88c0ef.mp4",
"https://telegra.ph/file/522a338c585c5b3c51671.mp4",
"https://telegra.ph/file/9aafcc540eff31cb63a8b.mp4",
"https://telegra.ph/file/7b4e823254354ac969ffe.mp4",
"https://telegra.ph/file/b07c3fb3c1c88572fad5c.mp4",
"https://telegra.ph/file/c45b2ec0650c5a0003f68.mp4",
"https://telegra.ph/file/069779c2abe682ba390e3.mp4",
"https://telegra.ph/file/db37195f7d702c3e95881.mp4",
"https://telegra.ph/file/4a6406a00d21d94aa6d4e.mp4",
"https://telegra.ph/file/58efef67fc9642dca6fff.mp4",
"https://telegra.ph/file/c4cc86663e87c95fed4db.mp4",
"https://telegra.ph/file/f9e6377474f05e683fd56.mp4",
"https://telegra.ph/file/9df0c9d6e46f8c6c8abed.mp4",
"https://telegra.ph/file/a4bec9dd316315e8a46d3.mp4",
"https://telegra.ph/file/68ae84423434384d98c2b.mp4",
"https://telegra.ph/file/6ebd85743d3514d4aae50.mp4",
"https://telegra.ph/file/2202d7970d37f1f5bb2cd.mp4",
"https://telegra.ph/file/f555859aba66ac9e0da31.mp4",
"https://telegra.ph/file/cfb0d9bafad666812a45b.mp4",
"https://telegra.ph/file/7760cd8cb42677a3c5ecc.mp4",
"https://telegra.ph/file/84bf637dd9cafb1449613.mp4",
"https://telegra.ph/file/92f9693e583b6dd2e7ce5.mp4",
"https://telegra.ph/file/d0e268a274aad73e75ebb.mp4",
"https://telegra.ph/file/8b5b354e9d466f2bedf5e.mp4",
"https://telegra.ph/file/c7c9a62fbbdc30cc65e3b.mp4",
"https://telegra.ph/file/2d3a8fe94d2dcf2784693.mp4",
"https://telegra.ph/file/ea382e086368f9b599844.mp4",
"https://telegra.ph/file/96cc886838c7a3a5a3412.mp4",
"https://telegra.ph/file/726fc8a43651d42203f61.mp4",
"https://telegra.ph/file/fdf7b61cdf30c9b9b5035.mp4",
"https://telegra.ph/file/ebf4747985f7d043330c2.mp4",
"https://telegra.ph/file/41fb77fff7ff2b022b792.mp4",
"https://telegra.ph/file/7d58e0edbd2f5f2fd5311.mp4",
"https://telegra.ph/file/bd0270f835c58c44c864d.mp4",
"https://telegra.ph/file/279940f9869ff0796da05.mp4",
"https://telegra.ph/file/728549bfb492709bb5fda.mp4",
"https://telegra.ph/file/c3fd41a27289aee09d9a7.mp4",
"https://telegra.ph/file/9f64f15cba9ec39b68957.mp4",
"https://telegra.ph/file/d1a6f5f12c41d6976a9d6.mp4",
"https://telegra.ph/file/45be2e7025edad5040c00.mp4",
"https://telegra.ph/file/c5a0c2e6290d98ce53237.mp4",
"https://telegra.ph/file/15f946f98870603f14f51.mp4",
"https://telegra.ph/file/c7c9a62fbbdc30cc65e3b.mp4"
]
